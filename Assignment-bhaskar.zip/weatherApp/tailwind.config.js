/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.{html,js}"],
  theme: {
    extend: {
      backgroundImage: {
        'sky': "url('/weatherApp/images/sky.jpg')",
      },
      container: {
        center: true,
      },  
    },
  },
  plugins: [],
}
